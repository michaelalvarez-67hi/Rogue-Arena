package com.roguearena.game

import android.annotation.SuppressLint
import android.app.Activity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections

class LanBridge(private val activity: Activity, private val webView: WebView) {
    private val lock = Any()
    @Volatile private var server: ServerSocket? = null
    @Volatile private var socket: Socket? = null
    @Volatile private var writer: BufferedWriter? = null

    @JavascriptInterface
    fun getLocalIp(): String {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            val addresses = interfaces.flatMap { Collections.list(it.inetAddresses) }
            val local = addresses.firstOrNull {
                it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress
            }
            local?.hostAddress ?: "IP no detectada"
        } catch (_: Exception) {
            "IP no detectada"
        }
    }

    @JavascriptInterface
    fun startHost() {
        Thread {
            disconnectInternal()
            try {
                val ss = ServerSocket(28765)
                server = ss
                status("Sala abierta en ${getLocalIp()}:28765. Esperando jugador…", false)
                val client = ss.accept()
                attach(client)
                status("¡Jugador conectado!", true)
                readLoop(client)
            } catch (e: Exception) {
                status("No se pudo abrir la sala: ${e.message ?: "error de red"}", false)
            } finally {
                disconnectInternal()
            }
        }.start()
    }

    @JavascriptInterface
    fun connectToHost(ip: String) {
        Thread {
            disconnectInternal()
            try {
                val client = Socket()
                client.connect(InetSocketAddress(ip.trim(), 28765), 5000)
                attach(client)
                status("Conectado al anfitrión.", true)
                readLoop(client)
            } catch (e: Exception) {
                status("Conexión fallida. Revisa la IP y el Wi-Fi.", false)
            } finally {
                disconnectInternal()
            }
        }.start()
    }

    @JavascriptInterface
    fun sendMessage(message: String) {
        try {
            synchronized(lock) {
                val out = writer ?: return
                out.write(message.replace("\n", " "))
                out.newLine()
                out.flush()
            }
        } catch (_: Exception) {
            status("Se perdió la conexión LAN.", false)
        }
    }

    @JavascriptInterface
    fun disconnect() {
        disconnectInternal()
        status("Desconectado.", false)
    }

    private fun attach(client: Socket) {
        client.tcpNoDelay = true
        client.keepAlive = true
        synchronized(lock) {
            socket?.close()
            socket = client
            writer = BufferedWriter(OutputStreamWriter(client.getOutputStream(), Charsets.UTF_8))
        }
    }

    private fun readLoop(client: Socket) {
        val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
        while (!client.isClosed) {
            val line = reader.readLine() ?: break
            if (line.length <= 4096) deliver(line)
        }
    }

    private fun deliver(message: String) {
        val quoted = JSONObject.quote(message)
        activity.runOnUiThread {
            webView.evaluateJavascript(
                "if(window.onRogueLANMessage)window.onRogueLANMessage($quoted);",
                null
            )
        }
    }

    private fun status(message: String, connected: Boolean) {
        val json = JSONObject()
            .put("type", "status")
            .put("text", message)
            .put("connected", connected)
            .toString()
        deliver(json)
    }

    private fun disconnectInternal() {
        synchronized(lock) {
            try { socket?.close() } catch (_: Exception) {}
            try { server?.close() } catch (_: Exception) {}
            socket = null
            server = null
            writer = null
        }
    }
}

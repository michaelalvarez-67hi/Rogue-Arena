# Rogue Arena · Neon Edition (Android)

Proyecto Android que empaqueta el juego HTML localmente dentro de una app llamada **Rogue Arena**. El juego no necesita internet para ejecutarse: el HTML, CSS y JavaScript están en `app/src/main/assets/index.html`.

## Abrir y compilar

1. Instala Android Studio en un ordenador.
2. Descomprime este proyecto y abre la carpeta `RogueArenaAndroid` desde Android Studio.
3. Espera a que Gradle sincronice el proyecto. Android Studio puede pedir descargar Android SDK 35 y los componentes de compilación.
4. Para crear el APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio mostrará la ubicación del APK generado. Normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Incluye

- Nombre de aplicación: Rogue Arena.
- Icono vectorial personalizado.
- WebView con JavaScript y almacenamiento local habilitados para que se conserven monedas, skins y progreso.
- Pantalla inmersiva vertical, sin barras del sistema durante el juego.
- Control del botón Atrás para pausar, volver al menú o salir.
- Juego sin recursos remotos ni permiso de internet.
- Versión visual Neon Edition, con 3 etapas en los niveles 1-9 y el nivel 10 conservado con 10 etapas.

## Nota

Este entorno no tiene instalado el Android SDK ni Gradle, por lo que aquí se entrega el proyecto listo para abrir y compilar en Android Studio, no un APK ya compilado.


## Compilarlo en la nube (sin instalar Android Studio en el móvil)

El proyecto incluye `.github/workflows/build-apk.yml`. Si subes el contenido del proyecto a un repositorio de GitHub, abre **Actions → Build Rogue Arena APK → Run workflow**. Cuando termine correctamente, entra al resultado de la ejecución y descarga el artefacto `Rogue-Arena-APK`; dentro estará `app-debug.apk`. La primera compilación puede tardar unos minutos.

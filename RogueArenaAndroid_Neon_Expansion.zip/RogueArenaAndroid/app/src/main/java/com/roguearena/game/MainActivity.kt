package com.roguearena.game

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var game: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 8, 18)
        window.navigationBarColor = Color.rgb(7, 8, 18)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersiveMode()

        game = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 8, 18))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(game)
    }

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    @Deprecated("Deprecated in Android API; kept for broad device compatibility")
    override fun onBackPressed() {
        if (!::game.isInitialized) {
            super.onBackPressed()
            return
        }
        game.evaluateJavascript(
            "(function(){if(typeof scene!=='undefined' && scene==='play'){setPause(true);return 'paused';}" +
                "if(typeof scene!=='undefined' && scene!=='menu'){showMenu();return 'menu';}" +
                "return 'exit';})()"
        ) { result ->
            if (result == "\"exit\"") finish()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    override fun onPause() {
        if (::game.isInitialized) game.evaluateJavascript("if(typeof setPause==='function')setPause(true)", null)
        super.onPause()
    }

    override fun onDestroy() {
        if (::game.isInitialized) {
            game.stopLoading()
            game.destroy()
        }
        super.onDestroy()
    }
}
